# Flat Hisab Manager — Android project

Ye project aapke existing Flat Hisab Manager HTML ko ek Android app ke andar chalata hai.

## Zaroori baat
- Is ZIP mein **APK binary abhi shamil nahi hai**; yeh Android Studio project/source hai.
- App ke records WebView ke `localStorage` mein isi phone par save hote hain. App data clear/uninstall karne par records mit sakte hain; app ke andar JSON backup/export ka option ho to use regularly use karein.
- Is project ko build karne ke liye Android Studio + Android SDK/Gradle ki zaroorat hai.

## Android Studio se APK banana
1. ZIP extract karein.
2. Android Studio kholein → **Open** → extracted `FlatHisabAndroid` folder select karein.
3. Gradle sync complete hone dein. Agar Android SDK 35 install karne ko kahe, install karein.
4. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)** select karein.
5. Build complete hone par `app/build/outputs/apk/debug/app-debug.apk` milega.
6. APK phone par bhejein, open karein, aur Android ke prompt ke mutabik is source se install permission allow karke install karein.

## GitHub Actions se cloud build
Is project mein `.github/workflows/build-apk.yml` bhi hai. GitHub par naya repository banakar project files upload/push karein. **Actions** tab mein `Build Android APK` workflow run karein; successful run ke Artifacts section se `Flat-Hisab-Manager-APK` download karein. APK install karne se pehle source ko review kar lena achha hai.
